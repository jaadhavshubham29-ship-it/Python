# Simple Log Analyzer

Run the simple analyzer:
