import re
from collections import Counter

# simple regex to detect log levels
LOG_PATTERN = re.compile(r"\b(INFO|WARNING|ERROR|CRITICAL)\b")

def analyze_log(path):
    counts = Counter()

    with open(path, "r") as file:
        for line in file:
            match = LOG_PATTERN.search(line)
            if match:
                level = match.group(1)
                counts[level] += 1

    return counts


if __name__ == "__main__":
    log_file = "server.log"       # default file name
    results = analyze_log(log_file)

    print("\n=== Simple Log Analysis ===")
    print(f"Log File: {log_file}")
    print("---------------------------")
    for level, count in results.items():
        print(f"{level}: {count}")
    
    print("---------------------------")
    print("Done.\n")
