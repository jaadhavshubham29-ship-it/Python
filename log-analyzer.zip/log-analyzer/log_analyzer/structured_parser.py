# structured_parser.py

def parse_structured_line(line: str) -> dict:
    """
    Parses a structured log line like:
    2025-01-01 12:00:00 [INFO] - User logged in

    Returns a dictionary:
    {
        "timestamp": "2025-01-01 12:00:00",
        "level": "INFO",
        "message": "User logged in"
    }
    """
    try:
        # Split timestamp + rest
        parts = line.split(" ", 2)
        timestamp = parts[0] + " " + parts[1]

        # Extract log level inside square brackets
        level_part = parts[2]
        level_start = level_part.find("[") + 1
        level_end = level_part.find("]")
        level = level_part[level_start:level_end]

        # Extract message (after '-')
        message = level_part.split(" - ", 1)[1]

        return {
            "timestamp": timestamp,
            "level": level,
            "message": message
        }
    except Exception:
        # If line is not structured, return None
        return None


if __name__ == "__main__":
    # Test the parser
    test_line = "2025-01-01 12:00:00 [INFO] - User logged in"
    print(parse_structured_line(test_line))
