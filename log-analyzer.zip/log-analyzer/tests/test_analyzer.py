import log_analyzer.simple_analyzer as sa

def test_log_summary():
    result = sa.analyze_log("server.log")

    # basic checks
    assert isinstance(result, dict) or hasattr(result, "items")
    assert result["INFO"] >= 1
    assert result["ERROR"] >= 1
    assert result["WARNING"] >= 1

import sys
import os

# force python to see project root
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

import log_analyzer.simple_analyzer as sa
